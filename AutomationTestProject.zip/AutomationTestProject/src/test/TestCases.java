package test;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Assert;

public class TestCases {
	
	
	@Test
	public void LondonCurrent() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\djrdv\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/djrdv/Downloads/Riya/Riya/index.html");
		
		WebElement LondonTab = driver.findElement(By.name("London"));
		LondonTab.click();
		
		String actOutput= driver.findElement(By.className("City")).getText();
		
		String ExpOutput = LondonTab.getText();
		Assert.assertEquals(ExpOutput, actOutput);
		
		driver.close();
	
	}
	
	@Test
	public void ParisCurrent() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\djrdv\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/djrdv/Downloads/Riya/Riya/index.html");
		
		WebElement LondonTab = driver.findElement(By.name("Paris"));
		LondonTab.click();
		
		String actOutput= driver.findElement(By.className("City")).getText();
		
		String ExpOutput = "Paris";
		Assert.assertEquals(ExpOutput, actOutput);
		
		driver.close();
	
	}
	
	@Test
	public void NewYorkCurrent() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\djrdv\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/djrdv/Downloads/Riya/Riya/index.html");
		
		WebElement LondonTab = driver.findElement(By.name("NewYork"));
		LondonTab.click();
		
		String actOutput= driver.findElement(By.className("City")).getText();
		
		String ExpOutput = "New York";
		Assert.assertEquals(ExpOutput, actOutput);
		
		driver.close();
	
	}
	
	@Test
	public void DelhiCurrent() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\djrdv\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/djrdv/Downloads/Riya/Riya/index.html");
		
		WebElement LondonTab = driver.findElement(By.name("Delhi"));
		LondonTab.click();
		
		String actOutput= driver.findElement(By.className("City")).getText();
		
		String ExpOutput = "दिल्ली";
		Assert.assertEquals(ExpOutput, actOutput);
		
		driver.close();
	
	}
	
	@Test
	public void TokyoCurrent() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\djrdv\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/djrdv/Downloads/Riya/Riya/index.html");
		
		WebElement LondonTab = driver.findElement(By.name("Tokyo"));
		LondonTab.click();
		
		String actOutput= driver.findElement(By.className("City")).getText();
		
		String ExpOutput = "東京都";
		Assert.assertEquals(ExpOutput, actOutput);
		
		driver.close();
	
	}
	

}
